@extends('layout')

@section('content')

	
	@foreach($disciplines as $discipline)

	
        <div class="panel-heading">
        	<span class="glyphicon glyphicon-list-alt"></span>

				<h1><a href="/disciplines/{{$discipline->id}}">{{$discipline->name}}</a></h1>
				<p>{{$discipline->abbreviation}}</p>

				{{Form::open(['url'=>'disciplines/'.$discipline->id,'method'=>'delete'])}}
					{{Form::hidden('course_id', $discipline->id)}}

					<div class="form-group">
							<a class="btn btn-info" href="/users/painelADM" role="button">Sair</a>

							<a class="btn btn-primary" href="/disciplines/{{$discipline->id}}/edit" role="button">Editar</a>

					        {{ Form::submit('Excluir Curso', array('class' => 'btn btn-danger')) }}

					        
					</div>
				{{Form::close()}}				
		</div>


	@endforeach

	{{ $disciplines->links() }}

@endsection