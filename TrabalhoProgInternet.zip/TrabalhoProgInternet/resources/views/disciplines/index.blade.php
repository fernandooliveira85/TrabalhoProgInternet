@extends('layout')

@section('content')



	@foreach($disciplines as $key => $discipline)


        <div class="panel-heading">
        	<span class="glyphicon glyphicon-list-alt"></span>

				<div class="form-group col-md-12">
					<div class="form-group col-md-4">
						<h1><a href="/disciplines/{{$discipline->id}}">{{$discipline->name}}</a></h1>
						<p>{{$discipline->abbreviation}}</p>

						{{Form::open(['url'=>'disciplines/'.$discipline->id,'method'=>'delete'])}}

							{{Form::hidden('course_id', $discipline->id)}}

							<div class="form-group">
									<a class="btn btn-info" href="/users/painelADM" role="button">Sair</a>

									<a class="btn btn-primary" href="/disciplines/{{$discipline->id}}/edit" role="button">Editar</a>

							        {{ Form::submit('Excluir Disciplina', array('class' => 'btn btn-danger')) }}
							</div>
						{{Form::close()}}
					</div>

					<div class="form-group col-md-4">
						<h2>Curso Vinculado</h1><br>

							{{-- Se der bug no Laravel $link->course->name --}}
							{{-- {{ $link->course['name']  --}}

						<?php $n = 1; ?>
						@foreach($courses_discipline[ $key ] as $link)
							{{$n++ }} -
							{{ $link->course['name'] }}
							<br>
						@endforeach

					</div>
				</div>
		</div>


	@endforeach

	{{ $disciplines->links() }}

@endsection
