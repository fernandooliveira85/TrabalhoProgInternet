@extends('layout')

@section('content')
	
	<div class="container">
	
	<legend><strong>Crie uma turma</strong></legend><br>
	
	<div class="row dadosLogin">
		<div class="form-group col-md-4">
			<center><label>Escolha um Curso</label><br> 
				
				<select name='course[]'	class="form-control" required>
				<option>...escolha uma disciplina</option>
				@foreach($courses as $course)
					<a> value="{{ $course->id }}" </a>
					<option>{{Form::label('courses[]', $course->name)}}</option>
				@endforeach
								
				</select>	
			</center> 
		</div>

		<div class="form-group col-md-5">
			<center><label>Vincule as disciplinas do semestre</label><br> 
				<select id="disciplines-select" class="form-control"></select>
			</center>	
		</div>

		<div class="form-group col-md-3">
			<center>
				<label>Escolha o semestre</label><br>
				<input name='period' type="radio" value="primeiro"> 1º Semestre<br>
				<input name='period' type="radio" value="primeiro"> 2º Semestre				
			</center>
		</div>

		<div class="form-group col-md-12">
			<a class="btn btn-info" href="/users/painelProf" role="button">Voltar</a>
			{{Form::submit('Salvar', array('class' => 'btn btn-success')) }}			
		</div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script>
    $('#courses-select').change(function(){
        var course_id = $(this).val();

        $.get('/get-disciplines/' + course_id, function(disciplines){
            $('#disciplines-select').empty();
            $.each(disciplines, function(key, value) {
                console.log(key);
                console.log(value);
                $('#disciplines-select').append('<option value=' + value.id + '>' + value.name + '</option>');
                alert('<option value=' + value.id + '>' + value.name + '</option>');
            });
        });
    });
    </script>
		
@endsection

