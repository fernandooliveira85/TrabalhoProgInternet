@extends('layout')

@section('content')

<!--scripts para o calendario de anos-->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>

<div class="panel panel-default">
    
    {{Form::open(['url'=>'disciplines','method'=>'POST'])}}

	<div class="form-group col-md-6">
		{{Form::label('name', 'Nome da Disciplina:')}}
		{{Form::text('name', null, ['placeholder'=>'Insira um nome da disciplina', 'class'=>'form-control'])}}
	</div>

	<div class="form-group col-md-6">
		{{Form::label('course', 'Vincule a um Curso:')}}<br>
			@foreach($courses as $course)
                <input name='courses[]' type="checkbox" value="{{ $course->id }}">
				{{Form::label('courses[]', $course->name)}}<br>
			@endforeach
	</div>
	
	<div class="form-group col-md-12">
		<a class="btn btn-info" href="/gerirDisciplina" role="button">Voltar</a>
		{{Form::submit('Salvar', array('class' => 'btn btn-success')) }}
	</div>
</div>
		

	{{Form::close()}}

@endsection
