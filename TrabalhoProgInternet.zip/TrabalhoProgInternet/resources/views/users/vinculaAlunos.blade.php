@extends('layout')

@section('content')

    
    {{Form::open(['url'=>'users','method'=>'put'])}}

	@foreach($users as $user)

        @if($user->type === "Aluno")
            <div class="form-group col-md-12">

                    <div class="form-group col-md-4">
                        <span class="glyphicon glyphicon-user"></span>

                            <h1><a href="/users/{{$user->id}}">{{$user->name}}</a></h1>
                            <p>{{$user->email}}</p>
                            <p>{{$user->password}}</p>
                            <p>{{$user->login}}</p>
                            <p>{{$user->type}}</p>
                            <p>{{$user->year}}</p>

                            {{Form::hidden('user_id', $user->id)}}

                            <div class="form-group">
                                <a class="btn btn-info" href="/users/gerenciaAl" role="button">Voltar</a>
                                {{Form::submit('Salvar', array('class' => 'btn btn-success')) }}
                            </div>


                            {{Form::close()}}
                    </div>

                    <div class="form-group col-md-8">
						<h2>Curso Vinculado</h1>
                            <?php $n = 1; ?>
    						@foreach($courses as $course)
    							<input name='courses[]' type="checkbox" value="{{ $course->id }}">
    							{{Form::label('courses[]', $course->name)}}
    							<br>
    						@endforeach

					</div>
    		</div>

        @endif
	@endforeach

	{{ $users->links() }}

@endsection
