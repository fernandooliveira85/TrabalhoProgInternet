@extends('layout')

@section('content')

<!--scripts para o calendario de anos-->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>



	<div class="container">
		
		<legend><strong>Painel de Controle Administrador</strong></legend><br>
		<div class="row dadosLogin">
			<div class="form-group col-md-6">
				<center><label>Cadastrar Usuário</label><br> 
					<a href="/users/create" class="hand"><img type="image" src="{{asset('img/add-user.png')}}" class="imgBtn4"></img></a>
				</center> 
			</div>
			
			<div class="form-group col-md-6">
				<center><label>Editar Usuarios</label><br> 
					<a href="{{route('users.index')}}" class="hand"><img type="image" src="{{asset('img/editarUsuario.png')}}" class="imgBtn4"></img></a>
				</center> 
			</div>
		</div><br>		
	</div>

@endsection