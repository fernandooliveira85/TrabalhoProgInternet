@extends('layout')

@section('content')


<div class="form-group col-md-12">
    <div class="content">
        <div class="titulo2">
            Gerenciamento de Trabalhos
        </div>

		<div class="form-group col-md-12">
	        <div class="titulo">
	        	<center>
	            	<a class="espaco" href="/users/painelADM">ADM</a>
	            	<a class="espaco" href="/users/painelProf">Professor</a>
	            	<a class="espaco" href="/users/painelAluno">Aluno</a>
	            </center>
	        </div>
	    </div>    
	</div>
</div>




@endsection