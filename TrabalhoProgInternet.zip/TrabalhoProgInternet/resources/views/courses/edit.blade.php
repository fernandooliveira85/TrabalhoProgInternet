@extends('layout')

@section('content')

 <div class="panel-heading">
        	
        	{{Form::open(['url'=>'courses/'.$course->id,'method'=>'put'])}}

        		<div class="form-group col-md-4">
					{{Form::label('name', 'Nome:')}}
					{{Form::text('name', $course->name, ['placeholder'=>'Insira um nome', 'class'=>'form-control'])}}
				</div>

				<div class="form-group col-md-4">
					{{Form::label('abbreviation', 'Abreviação:')}}
					{{Form::text('abbreviation', $course->abbreviation, ['placeholder'=>'..', 'class'=>'form-control'])}}
	
				</div>

				{{Form::close()}}

</div>
		

@endsection