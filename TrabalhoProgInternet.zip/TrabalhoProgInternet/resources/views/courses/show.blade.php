@extends('layout')

<style type="text/css">
	.link-show{
		color: #331189;
		cursor: pointer;
	}

</style>

@section('content')
	<div class="panel panel-default">
        <div class="panel-heading">
			<h1>{{$course->name}}</h1>

			<p>{{$course->id}}</p>
			<p>{{$course->abbreviation}}</p>

			<a class="btn btn-primary" href="/courses" role="button">Voltar</a>

		</div>
	</div>

@endsection