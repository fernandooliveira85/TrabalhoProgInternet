<?php $__env->startSection('content'); ?>

 <div class="panel-heading">
        	
        	<?php echo e(Form::open(['url'=>'courses/'.$course->id,'method'=>'put'])); ?>


        		<div class="form-group col-md-4">
					<?php echo e(Form::label('name', 'Nome:')); ?>

					<?php echo e(Form::text('name', $course->name, ['placeholder'=>'Insira um nome', 'class'=>'form-control'])); ?>

				</div>

				<div class="form-group col-md-4">
					<?php echo e(Form::label('abbreviation', 'Abreviação:')); ?>

					<?php echo e(Form::text('abbreviation', $course->abbreviation, ['placeholder'=>'..', 'class'=>'form-control'])); ?>

	
				</div>

				<div class="form-group col-md-12">
					<a class="btn btn-primary" href="/courses" role="button">Voltar</a>
						<?php echo e(Form::submit('Salvar', array('class' => 'btn btn-success'))); ?>

				</div>

				<?php echo e(Form::close()); ?>


</div>
		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>