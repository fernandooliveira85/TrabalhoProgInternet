<?php $__env->startSection('content'); ?>

<!--scripts para o calendario de anos-->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>



	<div class="container">
		
			<legend>
				<strong>Painel de Controle Professor</strong>
			</legend><br>
				<div class="row dadosLogin">
					<div class="form-group col-md-3">
						<center><label>Cadastrar Disciplina</label><br> 
							<a href="registerDisc" class="hand"><img type="image" src="<?php echo e(asset('img/Disciplina.png')); ?>" class="imgBtn4"></img></a>
						</center> 
					</div>
					
					<div class="form-group col-md-3">
						<center><label>Cadastrar Trabalho</label><br> 
							<a href="<?php echo e(route('users.index')); ?>" class="hand"><img type="image" src="<?php echo e(asset('img/Prova.png')); ?>" class="imgBtn4"></img></a>
						</center> 
					</div>

					<div class="form-group col-md-3">
						<center><label>Entrega de Trabalhos</label><br> 
							<a href="/gerir" class="hand"><img type="image" src="<?php echo e(asset('img/entrTrab.png')); ?>" class="imgBtn4"></img></a>
						</center> 
					</div>

					<div class="form-group col-md-3">
						<center>
						<label for="campo2">Trocar senha</label><br> 
							<a><href="TrocarSenha.html" class="hand"><img type="image" src="<?php echo e(asset('img/trocaSenha.png')); ?>" alt="teste" class="imgBtn4"></img></a>
						</center>
					</div>
					
				</div>

				<br>
		
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>