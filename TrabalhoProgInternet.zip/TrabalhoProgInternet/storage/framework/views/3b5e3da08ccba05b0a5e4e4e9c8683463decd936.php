<?php $__env->startSection('content'); ?>

	
	<?php $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	
        <div class="panel-heading">
        	<span class="glyphicon glyphicon-list-alt"></span>

				<h1><a href="/disciplines/<?php echo e($discipline->id); ?>"><?php echo e($discipline->name); ?></a></h1>
				<p><?php echo e($discipline->abbreviation); ?></p>

				<?php echo e(Form::open(['url'=>'disciplines/'.$discipline->id,'method'=>'delete'])); ?>

					<?php echo e(Form::hidden('course_id', $discipline->id)); ?>


					<div class="form-group">
							<a class="btn btn-info" href="/users/painelADM" role="button">Sair</a>

							<a class="btn btn-primary" href="/disciplines/<?php echo e($discipline->id); ?>/edit" role="button">Editar</a>

					        <?php echo e(Form::submit('Excluir Curso', array('class' => 'btn btn-danger'))); ?>


					        
					</div>
				<?php echo e(Form::close()); ?>				
		</div>


	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php echo e($disciplines->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>