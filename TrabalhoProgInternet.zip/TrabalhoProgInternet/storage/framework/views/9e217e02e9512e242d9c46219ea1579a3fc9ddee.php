<?php $__env->startSection('content'); ?>

<!--scripts para o calendario de anos-->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>

<div class="panel panel-default">
    
    <?php echo e(Form::open(['url'=>'courses','method'=>'POST'])); ?>


	<div class="form-group col-md-6">
		<?php echo e(Form::label('nome', 'Nome do Curso:')); ?>

		<?php echo e(Form::text('name', null, ['placeholder'=>'Insira um nome do curso', 'class'=>'form-control'])); ?>


	</div>	


	<div class="form-group col-md-4">
		<?php echo e(Form::label('abbreviation', 'Abreviação do Curso:')); ?>

		<?php echo e(Form::text('abbreviation', null, ['placeholder'=>'..abreviação', 'class'=>'form-control'])); ?>


	</div>

	<div class="form-group col-md-12">
		<a class="btn btn-info" href="/gerir" role="button">Voltar</a>
		<?php echo e(Form::submit('Salvar', array('class' => 'btn btn-success'))); ?>

	</div>
</div>
		

	<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>