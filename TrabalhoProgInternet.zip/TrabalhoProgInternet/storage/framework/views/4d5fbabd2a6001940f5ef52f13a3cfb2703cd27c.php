<?php $__env->startSection('content'); ?>


<div class="form-group col-md-12">
    <div class="content">
        <div class="titulo2">
            Gerenciamento de Trabalhos
        </div>

		<div class="form-group col-md-12">
	        <div class="titulo">
	        	<center>
	            	<a class="espaco" href="/users/painelADM">ADM</a>
	            </center>
	        </div>
	    </div>    
	</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>