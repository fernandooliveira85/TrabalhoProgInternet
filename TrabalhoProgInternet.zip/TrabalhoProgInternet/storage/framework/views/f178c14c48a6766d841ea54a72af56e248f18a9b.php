<?php $__env->startSection('content'); ?>

<!--scripts para o calendario de anos-->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>



<div class="container">
	
	<legend><strong>Gerenciar Disciplina</strong></legend><br>
	
	<div class="row dadosLogin">
		<div class="form-group col-md-6">
			<center><label>Criar Disciplina</label><br> 
				<a href="<?php echo e(route('disciplines.create')); ?>" class="hand"><img type="image" src="<?php echo e(asset('img/Disciplina.png')); ?>" class="imgBtn4"></img></a>
			</center> 
		</div>
		
		<div class="form-group col-md-6">
			<center><label>Editar Disciplina</label><br> 
				<a href="/disciplines" class="hand"><img type="image" src="<?php echo e(asset('img/editarCurso.png')); ?>" class="imgBtn4"></img></a>
			</center> 
		</div>					
	</div>

	<br>
	
	<div class="form-group col-md-12">
		<a class="btn btn-info" href="/users/painelADM" role="button">Voltar</a>
	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>