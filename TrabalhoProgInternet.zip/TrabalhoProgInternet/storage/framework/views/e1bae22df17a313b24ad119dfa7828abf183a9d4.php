<?php $__env->startSection('content'); ?>

 <div class="panel-heading">
        	
        	<?php echo e(Form::open(['url'=>'disciplines/'.$discipline->id,'method'=>'put'])); ?>

        		<div class="form-group col-md-6">
					<?php echo e(Form::label('name', 'Nome:')); ?>

					<?php echo e(Form::text('name', $discipline->name, ['placeholder'=>'Insira um nome', 'class'=>'form-control'])); ?>

				</div>

				<div class="form-group col-md-6">
					<?php echo e(Form::label('course', 'Vincule a um Curso:')); ?><br>
						<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <input name='courses[]' <?php echo e(in_array($course->id, $coursesSelect) ? 'checked' : ''); ?> type="checkbox" value="<?php echo e($course->id); ?>">
							<?php echo e(Form::label('courses[]', $course->name)); ?><br>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>


				<div class="form-group col-md-12">
					<a class="btn btn-primary" href="/disciplines" role="button">Voltar</a>
					<?php echo e(Form::submit('Salvar', array('class' => 'btn btn-success'))); ?>

				</div>

			<?php echo e(Form::close()); ?>


</div>
		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>