<style type="text/css">
	.link-show{
		color: #331189;
		cursor: pointer;
	}

</style>

<?php $__env->startSection('content'); ?>
	<div class="panel panel-default">
        <div class="panel-heading">
			<h1><?php echo e($user->name); ?></h1>

			<p><?php echo e($user->id); ?></p>
			<p><?php echo e($user->email); ?></p>
			<p><?php echo e($user->password); ?></p>
			<p><?php echo e($user->login); ?></p>
			<p><?php echo e($user->type); ?></p>
			<p><?php echo e($user->year); ?></p>

			<a class="btn btn-primary" href="/users" role="button">Voltar</a>

		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>