<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $fillable=['name', 'abbreviation'];

	public function disciplines()
    {
    	return $this->belongsToMany('App\Discipline','course__disciplines', 'discipline_id', 'course_id')->withPivot(['period']);
    }
}



