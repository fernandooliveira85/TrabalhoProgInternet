<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Course;

class CoursesController extends Controller
{
	 public function gerir()
	{
	    return view('courses.gerenciarCurso');
	}

	   public function index()
    {
    	//return \App\Post::all();
    	//$posts = post::all();
    	$courses = Course::paginate(5);
    	return view('courses.index', compact('courses'));
    }

    public function create()
	{
	    return view('courses.create');
	}

	public function show ($id)
    {
        $course = Course::find($id);
        return view('courses.show', compact('course'));
    }

        public function store(Request $request)
    {
        Course::create($request->all());
        return redirect('courses');
    }

        public function edit($id)
    {
        $course = Course::find($id);
        return view('courses.edit', compact('course'));
    }
}