<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Discipline;

class DisciplinesController extends Controller
{
    public function index()
    {
    	//return \App\Post::all();
    	//$posts = post::all();
    	$disciplines = Discipline::paginate(5);
    	return view('disciplines.index', compact('disciplines'));
    }

        public function gerir()
    {
        return view('disciplines.gerenciarDisciplina');
    }

	public function create()
	{
	    return view('disciplines.create');
	}

	public function store(Request $request)
    {
        Discipline::create($request->all());
        return redirect('disciplines');
    }

    public function edit($id)
    {
        $discipline = Discipline::find($id);
        return view('disciplines.edit', compact('discipline'));
    }

	public function update(Request $request, $id)
    {
        Discipline::find($id)->update($request->all());
        return redirect('disciplines');
    }

	public function destroy($id){
        Discipline::find($id)->delete();
        return redirect('DisciplinesController');
    }

}
